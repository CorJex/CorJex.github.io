export class uye{
    key:string
    adsoyad:string
    mail:string
    parola:string
    uid:string
}