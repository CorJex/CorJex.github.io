export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCRgfdMvO4777sHxGDFWdvsSFsufQaXiWo",
    authDomain: "ibrahimakay-crudproje.firebaseapp.com",
    databaseURL: "https://ibrahimakay-crudproje-default-rtdb.firebaseio.com",
    projectId: "ibrahimakay-crudproje",
    storageBucket: "ibrahimakay-crudproje.appspot.com",
    messagingSenderId: "29391029403",
    appId: "1:29391029403:web:8d217d6e82e0b59b13723e",
    measurementId: "G-WLC23Y7XE1"
  }
};
