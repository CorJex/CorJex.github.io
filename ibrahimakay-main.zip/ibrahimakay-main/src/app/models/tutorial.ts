export default class Tutorial {
  key: string;
  title: string;
  description: number;
  published = false;
}
