export class Kayit {
    key: string;
    baslik: string;
    icerik: string;
    uid: string;
    kayTarih: string;
    duzTarih: string;
}